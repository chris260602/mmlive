import { Sequelize } from "sequelize";
declare const sequalizeConnection: Sequelize;
export default sequalizeConnection;
//# sourceMappingURL=dbConnect.d.ts.map