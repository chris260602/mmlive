export {};
//# sourceMappingURL=database.d.ts.map