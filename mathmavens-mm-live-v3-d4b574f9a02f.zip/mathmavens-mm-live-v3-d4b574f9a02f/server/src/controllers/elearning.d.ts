import { RequestHandler } from "express";
export declare const createElearning: RequestHandler;
export declare const getElearnings: RequestHandler;
//# sourceMappingURL=elearning.d.ts.map